package judge.tool;

import javax.servlet.ServletContext;

public class ApplicationContainer {

    public static ServletContext serveletContext;

}
