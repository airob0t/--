package judge.action;

import com.opensymphony.xwork2.ActionSupport;

public class MainAction extends ActionSupport{

    private static final long serialVersionUID = -6947562558801998877L;

    public String toIndex(){
        return SUCCESS;
    }

    public String discuss(){
        return SUCCESS;
    }

}
